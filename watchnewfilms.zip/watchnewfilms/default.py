import urllib,urllib2,re,sys,xbmcplugin,xbmcgui,cookielib,os
#watchnewfilms.net -- nixa


def CATS():
        addDir('movies (09)','http://watchnewfilms.com/movies.php?code=9',1,'')
        addDir('movies (08)','http://watchnewfilms.com/movies.php?code=3',1,'')
        addDir('movies (02-07)','http://watchnewfilms.com/movies.php?code=5',1,'')
        addDir('recently added (09)','http://watchnewfilms.com/movies.php?code=9#',1,'')
        addDir('recently added (08)','http://watchnewfilms.com/movies.php?code=3#',1,'')
        addDir('recently added (02-07)','http://watchnewfilms.com/movies.php?code=5#',1,'')
        #addDir('Search','http://www.start2enjoy.com/',4,'')


def INDEX(url,name):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
	response = urllib2.urlopen(req)
        link=response.read()
        response.close()
	if url.find('#')<0:
        	try:
			match1=re.compile('<td width=".+?" align="center" style="padding:.+?" height=".+?" valign="bottom">\n		      <a class=".+?" href="(.+?)"><img src=".+?" width=".+?" height=".+?" border=".+?">\n		      <span><img src="(.+?)"><br>(.+?)  .+?</span></a>').findall(link)
			for url,thumbnail,name in match1:
				addDir(name,'http://watchnewfilms.com/'+url,2,thumbnail)
		except: pass
	if url.find('#')>0:
		try:	
			match2=re.compile('<td align="center" valign="top" style="padding:.+?" class="TextObject">\n      <a class=".+?" href="(.+?)"><img src=".+?" width=".+?" height=".+?" border=".+?">\n      <span><img src="(.+?)"><br>(.+?)  .+?</span></a>').findall(link)
			for url,thumbnail,name in match2:
				addDir(name,'http://watchnewfilms.com/'+url,2,thumbnail)
		except: pass

def SEL(url,name):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
        response = urllib2.urlopen(req)
        link=response.read()
	match1=re.compile('value="Watch Movie at DiVX" style="width:210px" onClick="window.open\(\'http://www.movshare.net/(.+?)\',.+?"').findall(link)
	match1a=re.compile('value="Watch Movie at DiVX" style="width:210px" onClick="window.open\(\'http://movshare.net/(.+?)\',.+?"').findall(link)
	match2=re.compile('value="Watch Movie at DiVX" style="width:210px" onClick="window.open\(\'http://divxstage.net/(.+?)\',.+?"').findall(link)
	match2a=re.compile('value="Watch Movie at DiVX" style="width:210px" onClick="window.open\(\'http://www.divxstage.net/(.+?)\',.+?"').findall(link)
	match3=re.compile('value="Watch Movie at Flash" style="width:210px" onClick="window.open\(\'http://www.novamov.com/(.+?)\',.+?"').findall(link)
	match5=re.compile('value="Watch Movie at Megavideo" style="width:210px" onClick="window.open\(\'http://www.megavideo.com/(.+?)\',.+?"').findall(link)
	match4=re.compile("src='http://www.movshare.net/embed/(.+?)'").findall(link)
	for url in match1:
		addDir(name+'[divx high speed]','http://www.movshare.net/'+url,3,'')
	for url in match1a:
		addDir(name+'[divx high speed]','http://movshare.net/'+url,3,'')
	for url in match2:
		addDir(name+'[divx]','http://divxstage.net/'+url,3,'')
	for url in match2a:
		addDir(name+'[divx]','http://www.divxstage.net/'+url,3,'')	
	for url in match3:
		addDir(name+'[flash]','http://www.novamov.com/'+url,3,'')
	for url in match4:
		addDir(name+'[divx]','http://www.movshare.net/video/'+url,3,'')
	for url in match5:
		addDir(name+'[flash]','http://www.megavideo.com/'+url,3,'')
      	try:
                megavideo=re.compile('<param name="movie" value="http://www.megavideo.com/v/(.+?)"></param>').findall(link)
               	mvid = megavideo[0]
                mvid = mvid[0:8]
                req = urllib2.Request("http://www.megavideo.com/xml/videolink.php?v="+mvid)
                req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
                req.add_header('Referer', 'http://www.megavideo.com/')
                lemon = urllib2.urlopen(req);response=lemon.read();lemon.close()
                errort = re.compile(' errortext="(.+?)"').findall(response)
                if len(errort) > 0: addLink(errort[0],'http://novid.com','')
                else:
                        s = re.compile(' s="(.+?)"').findall(response)
                        k1 = re.compile(' k1="(.+?)"').findall(response)
                        k2 = re.compile(' k2="(.+?)"').findall(response)
                        un = re.compile(' un="(.+?)"').findall(response)
                        movielink = "http://www" + s[0] + ".megavideo.com/files/" + decrypt(un[0], k1[0], k2[0]) + "/"
                        addLink(name, movielink+'?.flv','')
        except: pass




def VIDS(url,name):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
        response = urllib2.urlopen(req)
        link=response.read()
	response.close()

	if url.find('movshare')>0:
		try:	
			user_agent = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
			values = {'name' : 'watch','action' : '#'}
			headers = { 'User-Agent' : user_agent }
			data = urllib.urlencode(values)
			req = urllib2.Request(url, data, headers)
			response = urllib2.urlopen(req)
			the_page = response.read()
			swap=re.compile('<embed type="video/divx" src="(.+?)&.+?"').findall(the_page)
			if not swap: swap=re.compile('<embed type="video/divx" src="(.+?)"').findall(the_page)
			for url in swap:
				addLink(name.replace('(',' ').replace(')',' ').replace('Comedy',' ').replace('Horror',' ').replace('Action',' ').replace('Drama',' ').replace('2008',' ').replace('2009',' ').replace('2007',' ').replace('2006',' ').replace('2005',' ').replace('[divx high speed]','').replace('[divx]',''),swap[0],'http://www.bitdefender.com/files/KnowledgeBase/img/movie_icon.png')
		except: pass

	if url.find('tomwans.com')>0:
		try:
			user_agent = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
			values = {'form method' : 'post','value' : '#'}
			headers = { 'User-Agent' : user_agent }
			data = urllib.urlencode(values)
			req = urllib2.Request(url, data, headers)
			response = urllib2.urlopen(req)
			the_page = response.read()
			swap=re.compile('<embed src="http://www.tomwans.com/flashplayer/player.swf?file=(.+?)').findall(the_page)
			for url in swap:
				addLink(name,swap[0],'http://www.bitdefender.com/files/KnowledgeBase/img/movie_icon.png')
		except: pass


	try:
		match3=re.compile('<embed type="video/divx" src="(.+?)&ec_rate=.+?').findall(link)
		for url in match3:
			addLink(name.replace('(',' ').replace(')',' ').replace('Comedy',' ').replace('Horror',' ').replace('Action',' ').replace('Drama',' ').replace('2008',' ').replace('2009',' ').replace('2007',' ').replace('2006',' ').replace('2005',' ').replace('[divx]',''),match3[0],'http://www.bitdefender.com/files/KnowledgeBase/img/movie_icon.png')
	except: pass
	try:
		flv=re.compile('"file","(.+?)"').findall(link)
		for url in flv:
			addLink(name.replace('(',' ').replace(')',' ').replace('Comedy',' ').replace('Horror',' ').replace('Action',' ').replace('Drama',' ').replace('2008',' ').replace('2009',' ').replace('2007',' ').replace('2006',' ').replace('2005',' ').replace('[divx]','').replace('[flash]',''),flv[0],'http://www.bitdefender.com/files/KnowledgeBase/img/movie_icon.png')
	except: pass
	try:
		f=re.compile('<a href="(.+?)" target="_blank"><img id=".+?" src=".+?" alt=".+?" title=".+?"').findall(link)
		req = urllib2.Request(f[0])
        	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
        	page = urllib2.urlopen(req);new=page.read();page.close()
		flv=re.compile('<embed src=\".+?file=(.+?)&skin.+?" type=\"application/x-shockwave-flash\"').findall(new)
		for url in flv:
			addLink('play from fstube',flv[0],'http://www.bitdefender.com/files/KnowledgeBase/img/movie_icon.png')
	except: pass

      	try:
                megavideo=re.compile('<param name="movie" value="http://www.megavideo.com/v/(.+?)"></param>').findall(link)
               	mvid = megavideo[0]
                mvid = mvid[0:8]
                req = urllib2.Request("http://www.megavideo.com/xml/videolink.php?v="+mvid)
                req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
                req.add_header('Referer', 'http://www.megavideo.com/')
                lemon = urllib2.urlopen(req);response=lemon.read();lemon.close()
                errort = re.compile(' errortext="(.+?)"').findall(response)
                if len(errort) > 0: addLink(errort[0],'http://novid.com','')
                else:
                        s = re.compile(' s="(.+?)"').findall(response)
                        k1 = re.compile(' k1="(.+?)"').findall(response)
                        k2 = re.compile(' k2="(.+?)"').findall(response)
                        un = re.compile(' un="(.+?)"').findall(response)
                        movielink = "http://www" + s[0] + ".megavideo.com/files/" + decrypt(un[0], k1[0], k2[0]) + "/"
                        addLink('Play '+name, movielink+'?.flv','')
        except: pass

def ajoin(arr):
    strtest = ''
    for num in range(len(arr)):
        strtest = strtest + str(arr[num])
    return strtest

def asplit(mystring):
    arr = []
    for num in range(len(mystring)):
        arr.append(mystring[num])
    return arr
	
def decrypt(str1, key1, key2):

    __reg1 = []
    __reg3 = 0
    while (__reg3 < len(str1)):
        __reg0 = str1[__reg3]
        holder = __reg0
        if (holder == "0"):
            __reg1.append("0000")
        else:
            if (__reg0 == "1"):
                __reg1.append("0001")
            else:
                if (__reg0 == "2"): 
                    __reg1.append("0010")
                else: 
                    if (__reg0 == "3"):
                        __reg1.append("0011")
                    else: 
                        if (__reg0 == "4"):
                            __reg1.append("0100")
                        else: 
                            if (__reg0 == "5"):
                                __reg1.append("0101")
                            else: 
                                if (__reg0 == "6"):
                                    __reg1.append("0110")
                                else: 
                                    if (__reg0 == "7"):
                                        __reg1.append("0111")
                                    else: 
                                        if (__reg0 == "8"):
                                            __reg1.append("1000")
                                        else: 
                                            if (__reg0 == "9"):
                                                __reg1.append("1001")
                                            else: 
                                                if (__reg0 == "a"):
                                                    __reg1.append("1010")
                                                else: 
                                                    if (__reg0 == "b"):
                                                        __reg1.append("1011")
                                                    else: 
                                                        if (__reg0 == "c"):
                                                            __reg1.append("1100")
                                                        else: 
                                                            if (__reg0 == "d"):
                                                                __reg1.append("1101")
                                                            else: 
                                                                if (__reg0 == "e"):
                                                                    __reg1.append("1110")
                                                                else: 
                                                                    if (__reg0 == "f"):
                                                                        __reg1.append("1111")

        __reg3 = __reg3 + 1

    mtstr = ajoin(__reg1)
    __reg1 = asplit(mtstr)
    __reg6 = []
    __reg3 = 0
    while (__reg3 < 384):
    
        key1 = (int(key1) * 11 + 77213) % 81371
        key2 = (int(key2) * 17 + 92717) % 192811
        __reg6.append((int(key1) + int(key2)) % 128)
        __reg3 = __reg3 + 1
    
    __reg3 = 256
    while (__reg3 >= 0):

        __reg5 = __reg6[__reg3]
        __reg4 = __reg3 % 128
        __reg8 = __reg1[__reg5]
        __reg1[__reg5] = __reg1[__reg4]
        __reg1[__reg4] = __reg8
        __reg3 = __reg3 - 1
    
    __reg3 = 0
    while (__reg3 < 128):
    
        __reg1[__reg3] = int(__reg1[__reg3]) ^ int(__reg6[__reg3 + 256]) & 1
        __reg3 = __reg3 + 1

    __reg12 = ajoin(__reg1)
    __reg7 = []
    __reg3 = 0
    while (__reg3 < len(__reg12)):

        __reg9 = __reg12[__reg3:__reg3 + 4]
        __reg7.append(__reg9)
        __reg3 = __reg3 + 4
        
    
    __reg2 = []
    __reg3 = 0
    while (__reg3 < len(__reg7)):
        __reg0 = __reg7[__reg3]
        holder2 = __reg0
    
        if (holder2 == "0000"):
            __reg2.append("0")
        else: 
            if (__reg0 == "0001"):
                __reg2.append("1")
            else: 
                if (__reg0 == "0010"):
                    __reg2.append("2")
                else: 
                    if (__reg0 == "0011"):
                        __reg2.append("3")
                    else: 
                        if (__reg0 == "0100"):
                            __reg2.append("4")
                        else: 
                            if (__reg0 == "0101"): 
                                __reg2.append("5")
                            else: 
                                if (__reg0 == "0110"): 
                                    __reg2.append("6")
                                else: 
                                    if (__reg0 == "0111"): 
                                        __reg2.append("7")
                                    else: 
                                        if (__reg0 == "1000"): 
                                            __reg2.append("8")
                                        else: 
                                            if (__reg0 == "1001"): 
                                                __reg2.append("9")
                                            else: 
                                                if (__reg0 == "1010"): 
                                                    __reg2.append("a")
                                                else: 
                                                    if (__reg0 == "1011"): 
                                                        __reg2.append("b")
                                                    else: 
                                                        if (__reg0 == "1100"): 
                                                            __reg2.append("c")
                                                        else: 
                                                            if (__reg0 == "1101"): 
                                                                __reg2.append("d")
                                                            else: 
                                                                if (__reg0 == "1110"): 
                                                                    __reg2.append("e")
                                                                else: 
                                                                    if (__reg0 == "1111"): 
                                                                        __reg2.append("f")
                                                                    
        __reg3 = __reg3 + 1

    endstr = ajoin(__reg2)
    return endstr


def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
        return param

def SEARCH():
        keyb = xbmc.Keyboard('', 'Search Watchnewfilms')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText()
                encode=urllib.quote(search)
                req = urllib2.Request('http://www.google.com/cse?cx=001850866918592844060%3A6xkipb9ht6y&ie=UTF-8&q='+encode+'&sa=Search+on+Watch+New+Films')
	        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        	page = urllib2.urlopen(req)
		link=page.read()
		lnk=re.compile('href="(.+?)" class=l onmousedown=').findall(link)
		link2=lnk[0]
		req = urllib2.Request(link2)
        	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
        	response = urllib2.urlopen(req)
        	link=response.read()
		match1=re.compile('value="Watch Movie at DiVX" style="width:210px" onClick="window.open\(\'http://www.movshare.net/(.+?)\',.+?"').findall(link)
		match1a=re.compile('value="Watch Movie at DiVX" style="width:210px" onClick="window.open\(\'http://movshare.net/(.+?)\',.+?"').findall(link)
		match2=re.compile('value="Watch Movie at DiVX" style="width:210px" onClick="window.open\(\'http://divxstage.net/(.+?)\',.+?"').findall(link)
		match2a=re.compile('value="Watch Movie at DiVX" style="width:210px" onClick="window.open\(\'http://www.divxstage.net/(.+?)\',.+?"').findall(link)
		match3=re.compile('value="Watch Movie at Flash" style="width:210px" onClick="window.open\(\'http://www.novamov.com/(.+?)\',.+?"').findall(link)
		match5=re.compile('value="Watch Movie at Megavideo" style="width:210px" onClick="window.open\(\'http://www.megavideo.com/(.+?)\',.+?"').findall(link)
		match4=re.compile("src='http://www.movshare.net/embed/(.+?)'").findall(link)
		for url in match1:
			addDir(name+'[divx high speed]','http://www.movshare.net/'+url,3,'')
		for url in match1a:
			addDir(name+'[divx high speed]','http://movshare.net/'+url,3,'')
		for url in match2:
			addDir(name+'[divx]','http://divxstage.net/'+url,3,'')
		for url in match2a:
			addDir(name+'[divx]','http://www.divxstage.net/'+url,3,'')	
		for url in match3:
			addDir(name+'[flash]','http://www.novamov.com/'+url,3,'')
		for url in match4:
			addDir(name+'[divx]','http://www.movshare.net/video/'+url,3,'')
		for url in match5:
			addDir(name+'[flash]','http://www.megavideo.com/'+url,3,'')
      		try:
                	megavideo=re.compile('<param name="movie" value="http://www.megavideo.com/v/(.+?)"></param>').findall(link)
               		mvid = megavideo[0]
                	mvid = mvid[0:8]
                	req = urllib2.Request("http://www.megavideo.com/xml/videolink.php?v="+mvid)
                	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
                	req.add_header('Referer', 'http://www.megavideo.com/')
                	lemon = urllib2.urlopen(req);response=lemon.read();lemon.close()
                	errort = re.compile(' errortext="(.+?)"').findall(response)
                	if len(errort) > 0: addLink(errort[0],'http://novid.com','')
                	else:
                        	s = re.compile(' s="(.+?)"').findall(response)
                        	k1 = re.compile(' k1="(.+?)"').findall(response)
                        	k2 = re.compile(' k2="(.+?)"').findall(response)
                        	un = re.compile(' un="(.+?)"').findall(response)
                        	movielink = "http://www" + s[0] + ".megavideo.com/files/" + decrypt(un[0], k1[0], k2[0]) + "/"
                        	addLink(name, movielink+'?.flv','')
        	except: pass

        

def addDir(name,url,mode,thumbnail):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=thumbnail)
        liz.setInfo( "video", { "Title":name})
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
     
def addLink(name,url,thumbnail):
        ok=True
        def Download(url,dest):
                dp = xbmcgui.DialogProgress()
                dp.create("Fast Pass Tv Download","Downloading File",url)
                urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))
        def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
                try:
                        percent = min((numblocks*blocksize*100)/filesize, 100)
                        print percent
                        dp.update(percent)
                except:
                        percent = 100
                        dp.update(percent)
                if dp.iscanceled():
                        dp.close()
        if xbmcplugin.getSetting("Download Flv") == "true":
                dialog = xbmcgui.Dialog()
                path = dialog.browse(3, 'Choose Download Directory', 'files', '', False, False, '')
                Download(url,path+name+'.flv')
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=thumbnail)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok


params=get_params()
url=None
name=None
mode=None
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
if mode==None or url==None or len(url)<1:
        print "categories"
        CATS()
elif mode==1:
        print "PAGE"
        INDEX(url,name)
elif mode==2:
        print "PAGE"
        SEL(url,name)
elif mode==3:
        print "PAGE"
        VIDS(url,name)
elif mode==4:
        print "SEARCH  :"+url
        SEARCH()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
